Asynchronous wrapper for OANDA's v20 REST API. Client methods return coroutines that can be runinside an asyncio event loop


