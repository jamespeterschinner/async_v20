class Interface(object):
    """Bass class to denote mixin interface class'"""
    pass