# async_v20

An asynchronous client application for the OANDA's v20 Rest Api. 
 
The package aims to provide an async version of the OANDA v20 python wrapper
